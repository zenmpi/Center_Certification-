server = '192.168.1.103'
login = 'root'
password = ''
DB = 'bot_cert'

